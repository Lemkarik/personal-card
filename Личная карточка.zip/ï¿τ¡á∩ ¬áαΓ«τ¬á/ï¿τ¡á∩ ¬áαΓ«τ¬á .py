from flask import Flask, render_template, url_for
from random import randint
import json

app = Flask(__name__)


@app.route('/member')
def random_member():
    with open("templates/astronauts.json", "rt", encoding="utf8") as f:
        data = json.loads(f.read())
    n = randint(0, 4)
    return render_template('member.html', member=data["members"][n],
                           info=', '.join(sorted(data["members"][n]["info"])),
                           src=url_for('static', filename=f'img/{data["members"][n]["photo"]}'),
                           link=url_for('static', filename='css/style.css'))


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')